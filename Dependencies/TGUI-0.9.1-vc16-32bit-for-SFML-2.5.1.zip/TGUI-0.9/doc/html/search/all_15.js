var searchData=
[
  ['v_1398',['V',['../structtgui_1_1Event.html#a647c4342d425d6f03185126fc6eb5cd9a5206560a306a2e085a437fd258eb57ce',1,'tgui::Event']]],
  ['validator_1399',['Validator',['../structtgui_1_1EditBox_1_1Validator.html',1,'tgui::EditBox']]],
  ['variant_1400',['Variant',['../classtgui_1_1Variant.html',1,'tgui::Variant&lt; FirstType, OtherTypes &gt;'],['../classtgui_1_1Variant.html#ab54b4c97e4dd73a668c202c3042dac3c',1,'tgui::Variant::Variant()'],['../classtgui_1_1Variant.html#abb8d89e4484b6dea6a8c9bb7c0dfbdb8',1,'tgui::Variant::Variant(const T &amp;value)']]],
  ['variant_3c_20tgui_3a_3astring_2c_20tgui_3a_3afont_2c_20tgui_3a_3acolor_2c_20tgui_3a_3aoutline_2c_20bool_2c_20float_2c_20tgui_3a_3atexture_2c_20tgui_3a_3atextstyles_2c_20std_3a_3ashared_5fptr_3c_20tgui_3a_3arendererdata_20_3e_20_3e_1401',['Variant&lt; tgui::String, tgui::Font, tgui::Color, tgui::Outline, bool, float, tgui::Texture, tgui::TextStyles, std::shared_ptr&lt; tgui::RendererData &gt; &gt;',['../classtgui_1_1Variant.html',1,'tgui']]],
  ['vector2_1402',['Vector2',['../classtgui_1_1Vector2.html',1,'tgui::Vector2&lt; T &gt;'],['../classtgui_1_1Vector2.html#af06f8645c8b4a200ab93576c402e7f3e',1,'tgui::Vector2::Vector2()'],['../classtgui_1_1Vector2.html#a882fde3868463724feee4a15b946d09c',1,'tgui::Vector2::Vector2(T xValue, T yValue)'],['../classtgui_1_1Vector2.html#afd764cde6b56bd75a65031da14e37e9c',1,'tgui::Vector2::Vector2(const Vector2&lt; U &gt; &amp;vec)'],['../classtgui_1_1Vector2.html#af2930c45bb64a565e6791b893fc89457',1,'tgui::Vector2::Vector2(const char *str)'],['../classtgui_1_1Vector2.html#a8cf550078894eb9fb19bc183f821fe75',1,'tgui::Vector2::Vector2(String str)']]],
  ['vector2_3c_20float_20_3e_1403',['Vector2&lt; float &gt;',['../classtgui_1_1Vector2.html',1,'tgui']]],
  ['vector2_3c_20std_3a_3asize_5ft_20_3e_1404',['Vector2&lt; std::size_t &gt;',['../classtgui_1_1Vector2.html',1,'tgui']]],
  ['vector2_3c_20unsigned_20int_20_3e_1405',['Vector2&lt; unsigned int &gt;',['../classtgui_1_1Vector2.html',1,'tgui']]],
  ['vertex_1406',['Vertex',['../structtgui_1_1Vertex.html',1,'tgui']]],
  ['vertical_1407',['Vertical',['../classtgui_1_1Sprite.html#a3ebf7132d60f5c6f4ca0c3ebd60ea9f8a06ce2a25e5d12c166a36f654dbea6012',1,'tgui::Sprite']]],
  ['verticalalignment_1408',['VerticalAlignment',['../classtgui_1_1Label.html#a2974ef71da25253342a8b3660b6d094c',1,'tgui::Label']]],
  ['verticallayout_1409',['VerticalLayout',['../classtgui_1_1VerticalLayout.html',1,'tgui']]]
];
